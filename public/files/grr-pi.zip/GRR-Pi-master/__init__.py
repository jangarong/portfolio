from wxGUI.GUI import CPGUI

if __name__ == '__main__':
    CPGUI()