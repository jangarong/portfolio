# Two Sigma: Stock Market Predictions

* Amateur Hour - Using Headlines to Predict Stocks (Silver) - https://www.kaggle.com/magichanics/amateur-hour-using-headlines-to-predict-stocks
* Amateur Hour - Predicting Stocks using LightGBM - https://github.com/Magichanics/Stock-Market-Predictions/blob/master/Amateur%20Hour%20-%20Predicting%20Stocks%20using%20LightGBM.ipynb

### Results - Predicting Stocks using LightGBM
* January 2019 - Top 19%, 530th.
* February 2019 - Top 18%, 522nd.
* March 2019 - Top 21%, 605th.
* April 2019 - Top 20%, 571th.
* May 2019 - Top 12%, 342nd.
* June 2019 - Top 22%, 622nd.
